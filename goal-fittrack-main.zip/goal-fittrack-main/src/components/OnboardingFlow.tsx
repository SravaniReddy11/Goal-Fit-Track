import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, Target, User, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface OnboardingData {
  age: string;
  sex: string;
  height: string;
  weight: string;
  bodyFat: string;
  activityLevel: string;
  goal: string;
  targetWeight: string;
  dietaryPrefs: string;
  mealFrequency: string;
  wakeTime: string;
  sleepTime: string;
  workoutWindow: string;
  trainingDays: string[];
  injuries: string;
  waterGoal: string;
}

const initialData: OnboardingData = {
  age: "",
  sex: "",
  height: "",
  weight: "",
  bodyFat: "",
  activityLevel: "",
  goal: "",
  targetWeight: "",
  dietaryPrefs: "",
  mealFrequency: "",
  wakeTime: "",
  sleepTime: "",
  workoutWindow: "",
  trainingDays: [],
  injuries: "",
  waterGoal: ""
};

export const OnboardingFlow = ({ onComplete }: { onComplete: () => void }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [data, setData] = useState<OnboardingData>(initialData);
  const { toast } = useToast();

  const totalSteps = 5;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const updateData = (field: keyof OnboardingData, value: string | string[]) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("No user found");

      const { error } = await supabase.from('profiles').insert({
        user_id: user.id,
        name: user.user_metadata?.name || '',
        age: parseInt(data.age),
        sex: data.sex,
        height_cm: parseFloat(data.height),
        weight_kg: parseFloat(data.weight),
        body_fat_percentage: data.bodyFat ? parseFloat(data.bodyFat) : null,
        activity_level: data.activityLevel,
        goal: data.goal,
        target_weight_kg: parseFloat(data.targetWeight),
        dietary_preferences: data.dietaryPrefs,
        meal_frequency: parseInt(data.mealFrequency),
        wake_time: data.wakeTime,
        sleep_time: data.sleepTime,
        workout_window: data.workoutWindow,
        training_days: data.trainingDays,
        injuries: data.injuries,
        water_goal_liters: parseFloat(data.waterGoal),
      });

      if (error) throw error;

      toast({
        title: "Profile Complete!",
        description: "Your personalized fitness plan is ready.",
      });
      onComplete();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleTrainingDayToggle = (day: string) => {
    const newDays = data.trainingDays.includes(day)
      ? data.trainingDays.filter(d => d !== day)
      : [...data.trainingDays, day];
    updateData("trainingDays", newDays);
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <User className="w-16 h-16 mx-auto text-primary" />
              <h2 className="text-2xl font-bold">Basic Information</h2>
              <p className="text-muted-foreground">Let's start with your physical profile</p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="25"
                    value={data.age}
                    onChange={(e) => updateData("age", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Sex</Label>
                  <RadioGroup value={data.sex} onValueChange={(value) => updateData("sex", value)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male">Male</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female">Female</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other">Other</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="175"
                    value={data.height}
                    onChange={(e) => updateData("height", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="70"
                    value={data.weight}
                    onChange={(e) => updateData("weight", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bodyFat">Body Fat % (optional)</Label>
                <Input
                  id="bodyFat"
                  type="number"
                  placeholder="15"
                  value={data.bodyFat}
                  onChange={(e) => updateData("bodyFat", e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <Activity className="w-16 h-16 mx-auto text-primary" />
              <h2 className="text-2xl font-bold">Activity & Goals</h2>
              <p className="text-muted-foreground">Tell us about your lifestyle and objectives</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Activity Level</Label>
                <RadioGroup value={data.activityLevel} onValueChange={(value) => updateData("activityLevel", value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="sedentary" id="sedentary" />
                    <Label htmlFor="sedentary">Sedentary (office job, little exercise)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light">Lightly Active (light exercise 1-3 days/week)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="moderate" id="moderate" />
                    <Label htmlFor="moderate">Moderately Active (moderate exercise 3-5 days/week)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="active" id="active" />
                    <Label htmlFor="active">Very Active (hard exercise 6-7 days/week)</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Primary Goal</Label>
                <RadioGroup value={data.goal} onValueChange={(value) => updateData("goal", value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="bulk" id="bulk" />
                    <Label htmlFor="bulk">Bulk / Muscle Gain</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cut" id="cut" />
                    <Label htmlFor="cut">Cut / Fat Loss</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="maintain" id="maintain" />
                    <Label htmlFor="maintain">Maintain Current Weight</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="targetWeight">Target Weight (kg)</Label>
                <Input
                  id="targetWeight"
                  type="number"
                  placeholder="75"
                  value={data.targetWeight}
                  onChange={(e) => updateData("targetWeight", e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <Target className="w-16 h-16 mx-auto text-primary" />
              <h2 className="text-2xl font-bold">Nutrition Preferences</h2>
              <p className="text-muted-foreground">Help us customize your meal plans</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dietaryPrefs">Dietary Preferences / Allergies</Label>
                <Textarea
                  id="dietaryPrefs"
                  placeholder="e.g., Vegetarian, no nuts, lactose intolerant..."
                  value={data.dietaryPrefs}
                  onChange={(e) => updateData("dietaryPrefs", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Preferred Meal Frequency</Label>
                <RadioGroup value={data.mealFrequency} onValueChange={(value) => updateData("mealFrequency", value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="3" id="three" />
                    <Label htmlFor="three">3 meals per day</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="4" id="four" />
                    <Label htmlFor="four">4 meals per day</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="5" id="five" />
                    <Label htmlFor="five">5+ smaller meals per day</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="waterGoal">Daily Water Goal (liters)</Label>
                <Input
                  id="waterGoal"
                  type="number"
                  step="0.5"
                  placeholder="3"
                  value={data.waterGoal}
                  onChange={(e) => updateData("waterGoal", e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold">Daily Schedule</h2>
              <p className="text-muted-foreground">When do you typically wake up, sleep, and workout?</p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="wakeTime">Wake Time</Label>
                  <Input
                    id="wakeTime"
                    type="time"
                    value={data.wakeTime}
                    onChange={(e) => updateData("wakeTime", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sleepTime">Sleep Time</Label>
                  <Input
                    id="sleepTime"
                    type="time"
                    value={data.sleepTime}
                    onChange={(e) => updateData("sleepTime", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="workoutWindow">Preferred Workout Window</Label>
                <RadioGroup value={data.workoutWindow} onValueChange={(value) => updateData("workoutWindow", value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="morning" id="morning" />
                    <Label htmlFor="morning">Morning (6:00 - 10:00)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="afternoon" id="afternoon" />
                    <Label htmlFor="afternoon">Afternoon (12:00 - 16:00)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="evening" id="evening" />
                    <Label htmlFor="evening">Evening (17:00 - 21:00)</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Preferred Training Days (Select 5-6)</Label>
                <div className="grid grid-cols-4 gap-2">
                  {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                    <div key={day} className="flex items-center space-x-2">
                      <Checkbox
                        id={day}
                        checked={data.trainingDays.includes(day)}
                        onCheckedChange={() => handleTrainingDayToggle(day)}
                      />
                      <Label htmlFor={day} className="text-sm">{day}</Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold">Final Details</h2>
              <p className="text-muted-foreground">Any limitations or special considerations?</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="injuries">Injuries / Physical Restrictions</Label>
                <Textarea
                  id="injuries"
                  placeholder="e.g., Lower back issues, knee problems, shoulder injury..."
                  value={data.injuries}
                  onChange={(e) => updateData("injuries", e.target.value)}
                />
              </div>

              <Card className="p-6 bg-primary/5 border-primary/20">
                <h3 className="font-semibold mb-4">Profile Summary</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="text-muted-foreground">Age:</span> {data.age} years old</p>
                  <p><span className="text-muted-foreground">Goal:</span> {data.goal || "Not specified"}</p>
                  <p><span className="text-muted-foreground">Activity Level:</span> {data.activityLevel || "Not specified"}</p>
                  <p><span className="text-muted-foreground">Training Days:</span> {data.trainingDays.join(", ") || "Not selected"}</p>
                  <p><span className="text-muted-foreground">Water Goal:</span> {data.waterGoal}L per day</p>
                </div>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl p-8 card-shadow">
        <div className="space-y-6">
          {/* Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Step {currentStep + 1} of {totalSteps}</span>
              <span>{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Current Step */}
          {renderStep()}

          {/* Navigation */}
          <div className="flex justify-between pt-6">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 0}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Previous
            </Button>

            <Button
              onClick={handleNext}
              className="gradient-primary flex items-center gap-2"
              disabled={currentStep === 3 && data.trainingDays.length < 5}
            >
              {currentStep === totalSteps - 1 ? "Complete Setup" : "Next"}
              {currentStep < totalSteps - 1 && <ArrowRight className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};