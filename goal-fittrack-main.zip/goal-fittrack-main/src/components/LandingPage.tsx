import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Activity, Target, TrendingUp, Users } from "lucide-react";
import heroImage from "@/assets/hero-fitness.jpg";
import { AuthDialog } from "./AuthDialog";
import { useToast } from "@/hooks/use-toast";
export const LandingPage = ({
  onGetStarted
}: {
  onGetStarted: () => void;
}) => {
  const [showAuth, setShowAuth] = useState(false);
  const {
    toast
  } = useToast();
  const features = [{
    icon: Activity,
    title: "Hourly Activity Tracking",
    description: "Track every hour of your day with precision - from workouts to meals to hydration."
  }, {
    icon: Target,
    title: "Personalized Diet Plans",
    description: "AI-generated meal plans that adapt to your goals, rotating every 1-2 weeks."
  }, {
    icon: TrendingUp,
    title: "Smart Progress Analytics",
    description: "Visualize your fitness journey with interactive charts and heatmaps."
  }, {
    icon: Users,
    title: "5-6 Day Gym Splits",
    description: "Professional workout plans tailored to your schedule and fitness level."
  }];
  const handleAuthSuccess = () => {
    setShowAuth(false);
    toast({
      title: "Welcome to Goal-FitTrack!",
      description: "Let's get your fitness journey started."
    });
    setTimeout(() => {
      onGetStarted();
    }, 1000);
  };
  return <div className="min-h-screen gradient-bg">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={heroImage} alt="Modern fitness gym environment" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 py-20">
          <div className="text-center space-y-8 slide-up">
            <div className="space-y-4">
              <h1 className="text-5xl bg-gradient-to-r from-primary via-accent to-primary-glow bg-clip-text text-green-500 font-extrabold md:text-8xl text-center">
                GOAL- Fit Track
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
                The ultimate fitness companion that tracks every hour, optimizes your nutrition, 
                and builds the perfect workout plan just for you.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gradient-primary text-lg px-8 py-6 glow-primary transition-spring hover:scale-105" onClick={() => setShowAuth(true)}>
                Start Your Journey
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-6 border-primary/50 hover:border-primary transition-smooth" onClick={() => {
              document.getElementById('features')?.scrollIntoView({
                behavior: 'smooth'
              });
            }}>
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold">Everything You Need</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive fitness tracking designed for serious athletes and beginners alike.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => <Card key={index} className="p-6 card-shadow border-border/50 hover:border-primary/50 transition-smooth slide-up group">
                <div className="space-y-4">
                  <div className="w-12 h-12 rounded-lg gradient-primary flex items-center justify-center group-hover:glow-primary transition-smooth">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </Card>)}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-card/30 backdrop-blur">
        <div className="container mx-auto px-4 text-center">
          <div className="space-y-6">
            <h2 className="text-4xl font-bold">Ready to Transform Your Fitness?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Join thousands who've already optimized their health with Goal-FitTrack's 
              comprehensive tracking and personalized plans.
            </p>
            <Button size="lg" className="gradient-primary text-lg px-8 py-6 glow-primary transition-spring hover:scale-105" onClick={() => setShowAuth(true)}>
              Get Started Free
            </Button>
          </div>
        </div>
      </section>

      <AuthDialog open={showAuth} onOpenChange={setShowAuth} onSuccess={handleAuthSuccess} />
    </div>;
};