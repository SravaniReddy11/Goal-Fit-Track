import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Calculator, Utensils } from "lucide-react";
import foodImage from "@/assets/food-tracking.jpg";
import { useToast } from "@/hooks/use-toast";

interface FoodItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  servingSize: string;
  confidence: number;
}

export const FoodCalculator = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [quantity, setQuantity] = useState("100");
  const [unit, setUnit] = useState("g");
  const [searchResults, setSearchResults] = useState<FoodItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const { toast } = useToast();

  // Mock food database
  const mockFoodDatabase: FoodItem[] = [
    { id: "1", name: "Chicken Breast", calories: 165, protein: 31, carbs: 0, fats: 3.6, servingSize: "100g", confidence: 95 },
    { id: "2", name: "Brown Rice", calories: 112, protein: 2.6, carbs: 23, fats: 0.9, servingSize: "100g", confidence: 90 },
    { id: "3", name: "Salmon Fillet", calories: 208, protein: 25, carbs: 0, fats: 12, servingSize: "100g", confidence: 92 },
    { id: "4", name: "Avocado", calories: 160, protein: 2, carbs: 9, fats: 15, servingSize: "100g", confidence: 88 },
    { id: "5", name: "Oatmeal", calories: 68, protein: 2.4, carbs: 12, fats: 1.4, servingSize: "100g", confidence: 85 },
    { id: "6", name: "Greek Yogurt", calories: 59, protein: 10, carbs: 3.6, fats: 0.4, servingSize: "100g", confidence: 93 },
    { id: "7", name: "Banana", calories: 89, protein: 1.1, carbs: 23, fats: 0.3, servingSize: "100g", confidence: 87 },
    { id: "8", name: "Broccoli", calories: 25, protein: 3, carbs: 5, fats: 0.4, servingSize: "100g", confidence: 90 }
  ];

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));

    const results = mockFoodDatabase.filter(food =>
      food.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    setSearchResults(results);
    setIsSearching(false);

    if (results.length === 0) {
      toast({
        title: "No results found",
        description: "Try a different food name or add a custom entry.",
      });
    }
  };

  const calculateMacros = (food: FoodItem, qty: number) => {
    const multiplier = qty / 100; // Convert to per 100g base
    return {
      calories: Math.round(food.calories * multiplier),
      protein: Math.round(food.protein * multiplier * 10) / 10,
      carbs: Math.round(food.carbs * multiplier * 10) / 10,
      fats: Math.round(food.fats * multiplier * 10) / 10
    };
  };

  const handleLogFood = (food: FoodItem) => {
    const macros = calculateMacros(food, parseFloat(quantity));
    toast({
      title: "Food logged!",
      description: `${food.name} (${quantity}${unit}) - ${macros.calories} calories added to today's intake.`,
    });
  };

  const recentFoods = [
    { name: "Chicken Breast", amount: "150g", calories: 248 },
    { name: "Brown Rice", amount: "80g", calories: 90 },
    { name: "Greek Yogurt", amount: "200g", calories: 118 },
    { name: "Banana", amount: "120g", calories: 107 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-warning to-warning/60 flex items-center justify-center">
          <Calculator className="w-12 h-12 text-white" />
        </div>
        <div>
          <h2 className="text-3xl font-bold">Food Calculator</h2>
          <p className="text-muted-foreground">Calculate calories and macros for any food</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Search Section */}
        <Card className="p-6 card-shadow">
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Search className="w-5 h-5" />
            Food Search
          </h3>
          
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Enter food name (e.g., chicken breast)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="flex-1"
              />
              <Button onClick={handleSearch} disabled={isSearching}>
                {isSearching ? "Searching..." : "Search"}
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="unit">Unit</Label>
                <select 
                  id="unit"
                  className="w-full px-3 py-2 bg-input border border-border rounded-md"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                >
                  <option value="g">grams (g)</option>
                  <option value="oz">ounces (oz)</option>
                  <option value="cup">cup</option>
                  <option value="piece">piece</option>
                </select>
              </div>
            </div>
          </div>

          {/* Search Results */}
          {searchResults.length > 0 && (
            <div className="mt-6 space-y-3">
              <h4 className="font-semibold">Search Results</h4>
              {searchResults.map((food) => {
                const macros = calculateMacros(food, parseFloat(quantity));
                return (
                  <Card key={food.id} className="p-4 border-border/50">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h5 className="font-medium">{food.name}</h5>
                          <Badge variant={food.confidence > 90 ? "secondary" : "outline"}>
                            {food.confidence}% match
                          </Badge>
                        </div>
                        <div className="grid grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-warning font-semibold">{macros.calories}</p>
                            <p className="text-muted-foreground">calories</p>
                          </div>
                          <div>
                            <p className="text-primary font-semibold">{macros.protein}g</p>
                            <p className="text-muted-foreground">protein</p>
                          </div>
                          <div>
                            <p className="text-accent font-semibold">{macros.carbs}g</p>
                            <p className="text-muted-foreground">carbs</p>
                          </div>
                          <div>
                            <p className="text-success font-semibold">{macros.fats}g</p>
                            <p className="text-muted-foreground">fats</p>
                          </div>
                        </div>
                      </div>
                      <Button size="sm" onClick={() => handleLogFood(food)}>
                        <Plus className="w-4 h-4 mr-1" />
                        Log
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </Card>

        {/* Recent & Quick Add */}
        <div className="space-y-6">
          {/* Food Image */}
          <Card className="p-0 overflow-hidden card-shadow">
            <img 
              src={foodImage} 
              alt="Healthy nutrition tracking" 
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="font-semibold">Track Your Nutrition</h3>
              <p className="text-sm text-muted-foreground">
                Get accurate calorie and macro information for thousands of foods
              </p>
            </div>
          </Card>

          {/* Recent Foods */}
          <Card className="p-6 card-shadow">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Utensils className="w-5 h-5" />
              Recent Foods
            </h3>
            <div className="space-y-3">
              {recentFoods.map((food, index) => (
                <div key={index} className="flex justify-between items-center p-3 rounded-lg bg-muted/30">
                  <div>
                    <p className="font-medium">{food.name}</p>
                    <p className="text-sm text-muted-foreground">{food.amount}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{food.calories} cal</p>
                    <Button size="sm" variant="ghost" className="h-6 px-2">
                      + Add
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Custom Entry */}
          <Card className="p-6 card-shadow">
            <h3 className="text-lg font-semibold mb-4">Quick Custom Entry</h3>
            <div className="space-y-3">
              <Input placeholder="Food name" />
              <div className="grid grid-cols-2 gap-2">
                <Input placeholder="Calories" type="number" />
                <Input placeholder="Protein (g)" type="number" />
              </div>
              <Button className="w-full gradient-primary">
                Add Custom Food
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};