import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dumbbell, 
  Clock, 
  Target, 
  TrendingUp, 
  Play, 
  Pause,
  RotateCcw,
  CheckCircle
} from "lucide-react";
import workoutImage from "@/assets/workout-planning.jpg";
import { useToast } from "@/hooks/use-toast";

interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  weight?: string;
  restTime: number;
  completed: boolean;
  notes?: string;
}

interface WorkoutPlan {
  id: string;
  name: string;
  description: string;
  estimatedTime: number;
  difficulty: string;
  exercises: Exercise[];
}

export const WorkoutPlanner = () => {
  const [activeWorkout, setActiveWorkout] = useState<WorkoutPlan | null>(null);
  const [currentExercise, setCurrentExercise] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [restTimer, setRestTimer] = useState(0);
  const { toast } = useToast();

  const workoutPlans: WorkoutPlan[] = [
    {
      id: "push",
      name: "Push Day - Chest & Triceps",
      description: "Upper body pushing movements focusing on chest, shoulders, and triceps",
      estimatedTime: 75,
      difficulty: "Intermediate",
      exercises: [
        { id: "1", name: "Barbell Bench Press", sets: 4, reps: "8-10", weight: "80kg", restTime: 180, completed: false },
        { id: "2", name: "Incline Dumbbell Press", sets: 3, reps: "10-12", weight: "30kg", restTime: 120, completed: false },
        { id: "3", name: "Dips", sets: 3, reps: "12-15", restTime: 90, completed: false },
        { id: "4", name: "Overhead Press", sets: 3, reps: "8-10", weight: "50kg", restTime: 120, completed: false },
        { id: "5", name: "Lateral Raises", sets: 3, reps: "15-20", weight: "12kg", restTime: 60, completed: false },
        { id: "6", name: "Tricep Extensions", sets: 3, reps: "12-15", weight: "25kg", restTime: 60, completed: false }
      ]
    },
    {
      id: "pull",
      name: "Pull Day - Back & Biceps", 
      description: "Upper body pulling movements targeting back, rear delts, and biceps",
      estimatedTime: 80,
      difficulty: "Intermediate",
      exercises: [
        { id: "7", name: "Deadlifts", sets: 4, reps: "6-8", weight: "120kg", restTime: 180, completed: false },
        { id: "8", name: "Pull-ups", sets: 3, reps: "8-12", restTime: 120, completed: false },
        { id: "9", name: "Barbell Rows", sets: 3, reps: "10-12", weight: "70kg", restTime: 120, completed: false },
        { id: "10", name: "Face Pulls", sets: 3, reps: "15-20", weight: "20kg", restTime: 60, completed: false },
        { id: "11", name: "Barbell Curls", sets: 3, reps: "10-12", weight: "30kg", restTime: 60, completed: false },
        { id: "12", name: "Hammer Curls", sets: 3, reps: "12-15", weight: "15kg", restTime: 60, completed: false }
      ]
    },
    {
      id: "legs",
      name: "Leg Day - Quads & Glutes",
      description: "Lower body workout focusing on quadriceps, glutes, and calves",
      estimatedTime: 90,
      difficulty: "Advanced",
      exercises: [
        { id: "13", name: "Squats", sets: 4, reps: "8-10", weight: "100kg", restTime: 180, completed: false },
        { id: "14", name: "Romanian Deadlifts", sets: 3, reps: "10-12", weight: "80kg", restTime: 120, completed: false },
        { id: "15", name: "Leg Press", sets: 3, reps: "15-20", weight: "200kg", restTime: 90, completed: false },
        { id: "16", name: "Walking Lunges", sets: 3, reps: "12 each", restTime: 90, completed: false },
        { id: "17", name: "Calf Raises", sets: 4, reps: "15-20", weight: "60kg", restTime: 60, completed: false },
        { id: "18", name: "Leg Curls", sets: 3, reps: "12-15", weight: "40kg", restTime: 60, completed: false }
      ]
    }
  ];

  const startWorkout = (plan: WorkoutPlan) => {
    setActiveWorkout(plan);
    setCurrentExercise(0);
    toast({
      title: "Workout Started!",
      description: `${plan.name} - Let's crush this session!`,
    });
  };

  const completeExercise = () => {
    if (!activeWorkout) return;

    const updated = { ...activeWorkout };
    updated.exercises[currentExercise].completed = true;
    setActiveWorkout(updated);
    
    if (currentExercise < updated.exercises.length - 1) {
      setCurrentExercise(prev => prev + 1);
      setIsResting(true);
      setRestTimer(updated.exercises[currentExercise].restTime);
    } else {
      // Workout complete
      toast({
        title: "Workout Complete!",
        description: "Great job! Your workout has been logged.",
      });
      setActiveWorkout(null);
    }
  };

  const skipRest = () => {
    setIsResting(false);
    setRestTimer(0);
  };

  const workoutStats = {
    thisWeek: {
      sessions: 4,
      totalTime: 320, // minutes
      avgIntensity: 8.2
    },
    thisMonth: {
      sessions: 16,
      totalTime: 1280,
      personalBests: 3
    }
  };

  if (activeWorkout) {
    const progress = (activeWorkout.exercises.filter(e => e.completed).length / activeWorkout.exercises.length) * 100;
    const currentEx = activeWorkout.exercises[currentExercise];

    return (
      <div className="space-y-6">
        {/* Workout Header */}
        <Card className="p-6 card-shadow">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-2xl font-bold">{activeWorkout.name}</h2>
              <p className="text-muted-foreground">{activeWorkout.description}</p>
            </div>
            <Button variant="outline" onClick={() => setActiveWorkout(null)}>
              End Workout
            </Button>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </Card>

        {/* Rest Timer */}
        {isResting && (
          <Card className="p-6 card-shadow border-accent/50 bg-accent/5">
            <div className="text-center space-y-4">
              <Clock className="w-12 h-12 mx-auto text-accent" />
              <div>
                <h3 className="text-xl font-bold">Rest Period</h3>
                <p className="text-3xl font-bold text-accent">{Math.floor(restTimer / 60)}:{(restTimer % 60).toString().padStart(2, '0')}</p>
              </div>
              <div className="flex gap-2 justify-center">
                <Button onClick={skipRest}>Skip Rest</Button>
                <Button variant="outline">
                  <Pause className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Current Exercise */}
        <Card className="p-6 card-shadow">
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold">{currentEx.name}</h3>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                  <span>{currentEx.sets} sets</span>
                  <span>{currentEx.reps} reps</span>
                  {currentEx.weight && <span>{currentEx.weight}</span>}
                  <span>{currentEx.restTime}s rest</span>
                </div>
              </div>
              <Badge variant="secondary">
                Exercise {currentExercise + 1} of {activeWorkout.exercises.length}
              </Badge>
            </div>

            <div className="flex justify-center">
              <Button 
                size="lg" 
                className="gradient-primary px-8" 
                onClick={completeExercise}
                disabled={isResting}
              >
                <CheckCircle className="w-5 h-5 mr-2" />
                Complete Set
              </Button>
            </div>
          </div>
        </Card>

        {/* Exercise List */}
        <Card className="p-6 card-shadow">
          <h3 className="text-lg font-semibold mb-4">Today's Exercises</h3>
          <div className="space-y-3">
            {activeWorkout.exercises.map((exercise, index) => (
              <div 
                key={exercise.id} 
                className={`flex justify-between items-center p-3 rounded-lg transition-smooth ${
                  index === currentExercise 
                    ? 'bg-primary/10 border border-primary/20' 
                    : exercise.completed 
                      ? 'bg-success/10 border border-success/20' 
                      : 'bg-muted/30'
                }`}
              >
                <div>
                  <p className={`font-medium ${exercise.completed ? 'line-through text-muted-foreground' : ''}`}>
                    {exercise.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {exercise.sets} × {exercise.reps} {exercise.weight && `@ ${exercise.weight}`}
                  </p>
                </div>
                {exercise.completed && <CheckCircle className="w-5 h-5 text-success" />}
                {index === currentExercise && !exercise.completed && <Play className="w-5 h-5 text-primary" />}
              </div>
            ))}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-success to-primary flex items-center justify-center">
          <Dumbbell className="w-12 h-12 text-white" />
        </div>
        <div>
          <h2 className="text-3xl font-bold">Workout Planner</h2>
          <p className="text-muted-foreground">Professional 5-6 day split programs</p>
        </div>
      </div>

      <Tabs defaultValue="today" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="today">Today's Workout</TabsTrigger>
          <TabsTrigger value="plans">All Plans</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="space-y-6">
          <Card className="p-0 overflow-hidden card-shadow">
            <img 
              src={workoutImage} 
              alt="Workout planning with equipment" 
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">Today's Recommended Workout</h3>
              <p className="text-muted-foreground mb-4">
                Based on your 5-day split and recovery schedule
              </p>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <Badge variant="secondary">Push Day</Badge>
                  <span className="text-sm text-muted-foreground">~75 minutes</span>
                </div>
                <Button 
                  className="gradient-primary"
                  onClick={() => startWorkout(workoutPlans[0])}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start Workout
                </Button>
              </div>
            </div>
          </Card>

          <div className="grid md:grid-cols-3 gap-4">
            <Card className="p-4 text-center card-shadow">
              <Target className="w-8 h-8 mx-auto text-primary mb-2" />
              <p className="font-semibold">Current Split</p>
              <p className="text-sm text-muted-foreground">Push/Pull/Legs</p>
            </Card>
            <Card className="p-4 text-center card-shadow">
              <Clock className="w-8 h-8 mx-auto text-accent mb-2" />
              <p className="font-semibold">This Week</p>
              <p className="text-sm text-muted-foreground">{workoutStats.thisWeek.sessions} sessions</p>
            </Card>
            <Card className="p-4 text-center card-shadow">
              <TrendingUp className="w-8 h-8 mx-auto text-success mb-2" />
              <p className="font-semibold">Streak</p>
              <p className="text-sm text-muted-foreground">12 days</p>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="plans" className="space-y-4">
          {workoutPlans.map((plan) => (
            <Card key={plan.id} className="p-6 card-shadow">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl font-semibold">{plan.name}</h3>
                    <Badge variant={plan.difficulty === 'Advanced' ? 'destructive' : 'secondary'}>
                      {plan.difficulty}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground">{plan.description}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      ~{plan.estimatedTime} min
                    </span>
                    <span className="flex items-center gap-1">
                      <Dumbbell className="w-4 h-4" />
                      {plan.exercises.length} exercises
                    </span>
                  </div>
                </div>
                <Button onClick={() => startWorkout(plan)}>
                  <Play className="w-4 h-4 mr-2" />
                  Start
                </Button>
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="stats" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6 card-shadow">
              <h3 className="text-lg font-semibold mb-4">This Week</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Workout Sessions</span>
                  <span className="font-semibold">{workoutStats.thisWeek.sessions}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Time</span>
                  <span className="font-semibold">{Math.floor(workoutStats.thisWeek.totalTime / 60)}h {workoutStats.thisWeek.totalTime % 60}m</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg Intensity</span>
                  <span className="font-semibold">{workoutStats.thisWeek.avgIntensity}/10</span>
                </div>
              </div>
            </Card>

            <Card className="p-6 card-shadow">
              <h3 className="text-lg font-semibold mb-4">This Month</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Total Sessions</span>
                  <span className="font-semibold">{workoutStats.thisMonth.sessions}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Time</span>
                  <span className="font-semibold">{Math.floor(workoutStats.thisMonth.totalTime / 60)}h</span>
                </div>
                <div className="flex justify-between">
                  <span>Personal Bests</span>
                  <span className="font-semibold text-primary">{workoutStats.thisMonth.personalBests}</span>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};