import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Clock, Activity, Utensils, Droplet, Plus, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface HourlyEntry {
  hour: number;
  steps: number;
  caloriesBurned: number;
  workoutTag: string;
  macros: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
  waterMl: number;
  notes: string;
}

export const HourlyTracker = () => {
  const [selectedHour, setSelectedHour] = useState<number | null>(null);
  const [entries, setEntries] = useState<Record<number, HourlyEntry>>({});
  const { toast } = useToast();

  const currentHour = new Date().getHours();
  const hours = Array.from({ length: 24 }, (_, i) => i);

  const getHourLabel = (hour: number) => {
    const period = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:00 ${period}`;
  };

  const getHourStatus = (hour: number) => {
    if (hour > currentHour) return 'future';
    if (entries[hour]) return 'logged';
    return 'pending';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'logged': return 'bg-success/20 border-success/50';
      case 'pending': return 'bg-warning/20 border-warning/50';
      case 'future': return 'bg-muted border-border';
      default: return 'bg-muted border-border';
    }
  };

  const handleSaveEntry = (hour: number, data: Partial<HourlyEntry>) => {
    const entry: HourlyEntry = {
      hour,
      steps: 0,
      caloriesBurned: 0,
      workoutTag: '',
      macros: { calories: 0, protein: 0, carbs: 0, fats: 0 },
      waterMl: 0,
      notes: '',
      ...entries[hour],
      ...data
    };

    setEntries(prev => ({ ...prev, [hour]: entry }));
    setSelectedHour(null);
    
    toast({
      title: "Entry Saved!",
      description: `${getHourLabel(hour)} activity logged successfully.`,
    });
  };

  const getTodaysSummary = () => {
    const loggedEntries = Object.values(entries);
    return {
      totalSteps: loggedEntries.reduce((sum, e) => sum + e.steps, 0),
      totalCalories: loggedEntries.reduce((sum, e) => sum + e.caloriesBurned, 0),
      totalWater: loggedEntries.reduce((sum, e) => sum + e.waterMl, 0),
      loggedMacros: loggedEntries.reduce(
        (sum, e) => ({
          calories: sum.calories + e.macros.calories,
          protein: sum.protein + e.macros.protein,
          carbs: sum.carbs + e.macros.carbs,
          fats: sum.fats + e.macros.fats
        }),
        { calories: 0, protein: 0, carbs: 0, fats: 0 }
      )
    };
  };

  const summary = getTodaysSummary();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-accent to-primary flex items-center justify-center">
          <Clock className="w-12 h-12 text-white" />
        </div>
        <div>
          <h2 className="text-3xl font-bold">Hourly Activity Tracker</h2>
          <p className="text-muted-foreground">Log your daily activities hour by hour</p>
        </div>
      </div>

      {/* Today's Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Steps</span>
          </div>
          <p className="text-2xl font-bold">{summary.totalSteps.toLocaleString()}</p>
        </Card>

        <Card className="p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-warning" />
            <span className="text-sm font-medium">Calories Burned</span>
          </div>
          <p className="text-2xl font-bold">{summary.totalCalories}</p>
        </Card>

        <Card className="p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <Utensils className="w-4 h-4 text-success" />
            <span className="text-sm font-medium">Calories Eaten</span>
          </div>
          <p className="text-2xl font-bold">{summary.loggedMacros.calories}</p>
        </Card>

        <Card className="p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <Droplet className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium">Water</span>
          </div>
          <p className="text-2xl font-bold">{(summary.totalWater / 1000).toFixed(1)}L</p>
        </Card>
      </div>

      {/* Hourly Grid */}
      <Card className="p-6 card-shadow">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold">Today's Hours</h3>
          <Badge variant="secondary">
            {Object.keys(entries).length} of {currentHour + 1} hours logged
          </Badge>
        </div>

        <div className="grid grid-cols-6 md:grid-cols-8 lg:grid-cols-12 gap-2">
          {hours.map((hour) => {
            const status = getHourStatus(hour);
            const entry = entries[hour];
            
            return (
              <Button
                key={hour}
                variant="outline"
                className={`h-16 flex-col text-xs ${getStatusColor(status)} transition-smooth hover:scale-105`}
                onClick={() => setSelectedHour(hour)}
                disabled={hour > currentHour}
              >
                <span className="font-medium">{getHourLabel(hour)}</span>
                {entry && (
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">
                      {entry.steps > 0 && <div>{entry.steps} steps</div>}
                      {entry.macros.calories > 0 && <div>{entry.macros.calories} cal</div>}
                    </div>
                  </div>
                )}
                {status === 'logged' && <div className="w-2 h-2 bg-success rounded-full" />}
              </Button>
            );
          })}
        </div>
      </Card>

      {/* Entry Form */}
      {selectedHour !== null && (
        <Card className="p-6 card-shadow">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold">
              Log Activity for {getHourLabel(selectedHour)}
            </h3>
            <Button variant="ghost" onClick={() => setSelectedHour(null)}>
              Close
            </Button>
          </div>

          <HourlyEntryForm 
            hour={selectedHour}
            existingEntry={entries[selectedHour]}
            onSave={(data) => handleSaveEntry(selectedHour, data)}
          />
        </Card>
      )}
    </div>
  );
};

interface EntryFormProps {
  hour: number;
  existingEntry?: HourlyEntry;
  onSave: (data: Partial<HourlyEntry>) => void;
}

const HourlyEntryForm = ({ hour, existingEntry, onSave }: EntryFormProps) => {
  const [formData, setFormData] = useState({
    steps: existingEntry?.steps?.toString() || '',
    caloriesBurned: existingEntry?.caloriesBurned?.toString() || '',
    workoutTag: existingEntry?.workoutTag || '',
    macroCalories: existingEntry?.macros?.calories?.toString() || '',
    protein: existingEntry?.macros?.protein?.toString() || '',
    carbs: existingEntry?.macros?.carbs?.toString() || '',
    fats: existingEntry?.macros?.fats?.toString() || '',
    waterMl: existingEntry?.waterMl?.toString() || '',
    notes: existingEntry?.notes || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    onSave({
      steps: parseInt(formData.steps) || 0,
      caloriesBurned: parseInt(formData.caloriesBurned) || 0,
      workoutTag: formData.workoutTag,
      macros: {
        calories: parseInt(formData.macroCalories) || 0,
        protein: parseFloat(formData.protein) || 0,
        carbs: parseFloat(formData.carbs) || 0,
        fats: parseFloat(formData.fats) || 0
      },
      waterMl: parseInt(formData.waterMl) || 0,
      notes: formData.notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        {/* Activity Data */}
        <div className="space-y-4">
          <h4 className="font-semibold flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Activity & Exercise
          </h4>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="steps">Steps</Label>
              <Input
                id="steps"
                type="number"
                placeholder="0"
                value={formData.steps}
                onChange={(e) => setFormData({ ...formData, steps: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="caloriesBurned">Calories Burned</Label>
              <Input
                id="caloriesBurned"
                type="number"
                placeholder="0"
                value={formData.caloriesBurned}
                onChange={(e) => setFormData({ ...formData, caloriesBurned: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="workoutTag">Workout/Activity Tag</Label>
            <Input
              id="workoutTag"
              placeholder="e.g., Push workout, Cardio, Walking"
              value={formData.workoutTag}
              onChange={(e) => setFormData({ ...formData, workoutTag: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="waterMl">Water Intake (ml)</Label>
            <Input
              id="waterMl"
              type="number"
              placeholder="250"
              value={formData.waterMl}
              onChange={(e) => setFormData({ ...formData, waterMl: e.target.value })}
            />
          </div>
        </div>

        {/* Nutrition Data */}
        <div className="space-y-4">
          <h4 className="font-semibold flex items-center gap-2">
            <Utensils className="w-4 h-4" />
            Nutrition Intake
          </h4>

          <div className="space-y-2">
            <Label htmlFor="macroCalories">Calories Consumed</Label>
            <Input
              id="macroCalories"
              type="number"
              placeholder="0"
              value={formData.macroCalories}
              onChange={(e) => setFormData({ ...formData, macroCalories: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-2">
              <Label htmlFor="protein">Protein (g)</Label>
              <Input
                id="protein"
                type="number"
                step="0.1"
                placeholder="0"
                value={formData.protein}
                onChange={(e) => setFormData({ ...formData, protein: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="carbs">Carbs (g)</Label>
              <Input
                id="carbs"
                type="number"
                step="0.1"
                placeholder="0"
                value={formData.carbs}
                onChange={(e) => setFormData({ ...formData, carbs: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="fats">Fats (g)</Label>
              <Input
                id="fats"
                type="number"
                step="0.1"
                placeholder="0"
                value={formData.fats}
                onChange={(e) => setFormData({ ...formData, fats: e.target.value })}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          placeholder="Any additional notes about this hour..."
          rows={3}
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
        />
      </div>

      {/* Actions */}
      <div className="flex gap-2 justify-end">
        <Button type="submit" className="gradient-primary">
          <Plus className="w-4 h-4 mr-2" />
          Save Entry
        </Button>
      </div>
    </form>
  );
};