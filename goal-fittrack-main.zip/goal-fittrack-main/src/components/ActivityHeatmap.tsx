import { Card } from "@/components/ui/card";

export const ActivityHeatmap = () => {
  // Generate mock data for the last 7 days, 24 hours each
  const generateHeatmapData = () => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const hours = Array.from({ length: 24 }, (_, i) => i);
    
    return days.map(day => ({
      day,
      hours: hours.map(hour => ({
        hour,
        activity: Math.random() * 5, // 0-5 intensity scale
        calories: Math.floor(Math.random() * 200), // 0-200 calories per hour
        type: getActivityType(hour) // morning/work/evening/sleep
      }))
    }));
  };

  const getActivityType = (hour: number) => {
    if (hour >= 6 && hour < 9) return 'morning';
    if (hour >= 9 && hour < 17) return 'work';
    if (hour >= 17 && hour < 22) return 'evening';
    return 'sleep';
  };

  const getIntensityColor = (activity: number) => {
    if (activity < 1) return 'bg-muted';
    if (activity < 2) return 'bg-primary/20';
    if (activity < 3) return 'bg-primary/40';
    if (activity < 4) return 'bg-primary/60';
    return 'bg-primary/80';
  };

  const data = generateHeatmapData();

  return (
    <div className="space-y-4">
      {/* Legend */}
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-4">
          <span className="text-muted-foreground">Less active</span>
          <div className="flex gap-1">
            {[0, 1, 2, 3, 4].map(level => (
              <div 
                key={level}
                className={`w-3 h-3 rounded-sm ${getIntensityColor(level)}`}
              />
            ))}
          </div>
          <span className="text-muted-foreground">More active</span>
        </div>
        <span className="text-muted-foreground">Last 7 days</span>
      </div>

      {/* Heatmap Grid */}
      <div className="space-y-2">
        {/* Hour labels */}
        <div className="grid grid-cols-25 gap-1 text-xs text-muted-foreground">
          <div></div> {/* Empty cell for day labels */}
          {Array.from({ length: 24 }, (_, i) => (
            <div key={i} className="text-center">
              {i % 4 === 0 ? `${i}h` : ''}
            </div>
          ))}
        </div>

        {/* Heatmap rows */}
        {data.map(({ day, hours }) => (
          <div key={day} className="grid grid-cols-25 gap-1">
            <div className="text-xs text-muted-foreground font-medium flex items-center">
              {day}
            </div>
            {hours.map(({ hour, activity, calories }) => (
              <div
                key={hour}
                className={`w-4 h-4 rounded-sm ${getIntensityColor(activity)} transition-all hover:scale-110 cursor-pointer relative group`}
                title={`${day} ${hour}:00 - Activity: ${activity.toFixed(1)} - ${calories} calories`}
              >
                {/* Tooltip */}
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-10">
                  <Card className="px-2 py-1 text-xs whitespace-nowrap">
                    <div>{day} {hour}:00</div>
                    <div>Activity: {activity.toFixed(1)}/5</div>
                    <div>{calories} calories</div>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
        <div className="text-center">
          <p className="text-2xl font-bold text-primary">
            {Math.floor(data.reduce((sum, day) => 
              sum + day.hours.reduce((daySum, hour) => daySum + hour.calories, 0), 0
            ))}
          </p>
          <p className="text-sm text-muted-foreground">Total Calories</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-accent">
            {Math.floor(data.reduce((sum, day) => 
              sum + day.hours.filter(hour => hour.activity > 2).length, 0
            ))}
          </p>
          <p className="text-sm text-muted-foreground">Active Hours</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-success">
            {data.filter(day => 
              day.hours.filter(hour => hour.activity > 3).length >= 2
            ).length}
          </p>
          <p className="text-sm text-muted-foreground">High Activity Days</p>
        </div>
      </div>
    </div>
  );
};