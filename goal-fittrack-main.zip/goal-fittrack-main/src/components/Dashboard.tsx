import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity, 
  Target, 
  Droplet, 
  Utensils, 
  Dumbbell, 
  TrendingUp,
  Calendar,
  Settings,
  User,
  LogOut,
  Plus
} from "lucide-react";
import { ActivityHeatmap } from "./ActivityHeatmap";
import { FoodCalculator } from "./FoodCalculator";
import { WorkoutPlanner } from "./WorkoutPlanner";
import { HourlyTracker } from "./HourlyTracker";
import { ProfilePage } from "./ProfilePage";
import { SettingsDialog } from "./SettingsDialog";
import { useToast } from "@/hooks/use-toast";

export const Dashboard = ({ onLogout }: { onLogout: () => void }) => {
  const [activeTab, setActiveTab] = useState("overview");
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const { toast } = useToast();
  const [userData, setUserData] = useState({
    name: "User",
    currentWeight: 0,
    targetWeight: 0,
    dailyCalories: 2800,
    consumedCalories: 2150,
    protein: { target: 140, consumed: 95 },
    carbs: { target: 350, consumed: 280 },
    fats: { target: 93, consumed: 65 },
    water: { target: 3.5, consumed: 2.1 },
    todayWorkout: "Push Day - Chest & Triceps"
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("No user found");

      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      if (profile) {
        setUserData(prev => ({
          ...prev,
          name: profile.name || user.user_metadata?.name || "User",
          currentWeight: profile.weight_kg,
          targetWeight: profile.target_weight_kg,
          water: {
            ...prev.water,
            target: profile.water_goal_liters || 3.5
          }
        }));
      }
    } catch (error: any) {
      toast({
        title: "Error loading profile",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const weeklyStats = [
    { day: "Mon", calories: 2850, protein: 145, workout: true },
    { day: "Tue", calories: 2750, protein: 138, workout: true },
    { day: "Wed", calories: 2900, protein: 152, workout: false },
    { day: "Thu", calories: 2650, protein: 135, workout: true },
    { day: "Fri", calories: 2800, protein: 142, workout: true },
    { day: "Sat", calories: 3100, protein: 158, workout: true },
    { day: "Sun", calories: 2600, protein: 130, workout: false },
  ];

  const quickActions = [
    { icon: Plus, label: "Log Meal", action: () => setActiveTab("food") },
    { icon: Dumbbell, label: "Start Workout", action: () => setActiveTab("workout") },
    { icon: Droplet, label: "Add Water", action: () => toast({ title: "Water logged!", description: "+250ml added to today's intake" }) },
    { icon: Activity, label: "Log Activity", action: () => setActiveTab("tracking") },
  ];

  const handleProfileBack = () => {
    setShowProfile(false);
    fetchUserProfile(); // Refresh data after profile edits
  };

  if (loading) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (showProfile) {
    return <ProfilePage onBack={handleProfileBack} />;
  }

  return (
    <div className="min-h-screen gradient-bg">
      {/* Header */}
      <header className="bg-card/50 backdrop-blur border-b border-border/50 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Goal-FitTrack
            </h1>
            <Badge variant="secondary" className="hidden sm:flex">
              Week 3 - Cut Phase
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowSettings(true)}>
              <Settings className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowProfile(true)}>
              <User className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={onLogout}>
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <SettingsDialog open={showSettings} onOpenChange={setShowSettings} />

      <div className="container mx-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tracking">Tracking</TabsTrigger>
            <TabsTrigger value="food">Food</TabsTrigger>
            <TabsTrigger value="workout">Workout</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Welcome Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold">Welcome back, {userData.name}!</h2>
                  <p className="text-muted-foreground">Here's your fitness summary for today</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Current Weight</p>
                  <p className="text-2xl font-bold text-primary">{userData.currentWeight}kg</p>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="h-20 flex-col gap-2 hover:border-primary/50 transition-smooth"
                    onClick={action.action}
                  >
                    <action.icon className="w-6 h-6" />
                    <span className="text-xs">{action.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Today's Progress */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Calories */}
              <Card className="p-6 card-shadow">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Utensils className="w-5 h-5 text-warning" />
                    <h3 className="font-semibold">Calories</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-2xl font-bold">{userData.consumedCalories}</span>
                      <span className="text-sm text-muted-foreground">/ {userData.dailyCalories}</span>
                    </div>
                    <Progress 
                      value={(userData.consumedCalories / userData.dailyCalories) * 100} 
                      className="h-2"
                    />
                    <p className="text-xs text-muted-foreground">
                      {userData.dailyCalories - userData.consumedCalories} remaining
                    </p>
                  </div>
                </div>
              </Card>

              {/* Protein */}
              <Card className="p-6 card-shadow">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-primary" />
                    <h3 className="font-semibold">Protein</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-2xl font-bold">{userData.protein.consumed}g</span>
                      <span className="text-sm text-muted-foreground">/ {userData.protein.target}g</span>
                    </div>
                    <Progress 
                      value={(userData.protein.consumed / userData.protein.target) * 100} 
                      className="h-2"
                    />
                  </div>
                </div>
              </Card>

              {/* Water */}
              <Card className="p-6 card-shadow">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Droplet className="w-5 h-5 text-accent" />
                    <h3 className="font-semibold">Water</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-2xl font-bold">{userData.water.consumed}L</span>
                      <span className="text-sm text-muted-foreground">/ {userData.water.target}L</span>
                    </div>
                    <Progress 
                      value={(userData.water.consumed / userData.water.target) * 100} 
                      className="h-2"
                    />
                  </div>
                </div>
              </Card>

              {/* Today's Workout */}
              <Card className="p-6 card-shadow">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Dumbbell className="w-5 h-5 text-success" />
                    <h3 className="font-semibold">Workout</h3>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">{userData.todayWorkout}</p>
                    <Badge variant="secondary" className="w-fit">
                      Scheduled 6:00 PM
                    </Badge>
                  </div>
                </div>
              </Card>
            </div>

            {/* Weekly Overview */}
            <Card className="p-6 card-shadow">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Weekly Overview
              </h3>
              <div className="grid grid-cols-7 gap-4">
                {weeklyStats.map((day, index) => (
                  <div key={index} className="text-center space-y-2">
                    <p className="text-sm font-medium">{day.day}</p>
                    <div className="space-y-1">
                      <div className="text-xs">
                        <p className="font-medium">{day.calories}</p>
                        <p className="text-muted-foreground">cals</p>
                      </div>
                      <div className="text-xs">
                        <p className="font-medium">{day.protein}g</p>
                        <p className="text-muted-foreground">protein</p>
                      </div>
                      <div className="mt-2">
                        {day.workout ? (
                          <Badge variant="secondary" className="text-xs">✓</Badge>
                        ) : (
                          <Badge variant="outline" className="text-xs">-</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="tracking">
            <HourlyTracker />
          </TabsContent>

          <TabsContent value="food">
            <FoodCalculator />
          </TabsContent>

          <TabsContent value="workout">
            <WorkoutPlanner />
          </TabsContent>

          <TabsContent value="analytics">
            <div className="space-y-6">
              <Card className="p-6 card-shadow">
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Activity Heatmap
                </h3>
                <ActivityHeatmap />
              </Card>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="p-6 card-shadow">
                  <h3 className="text-lg font-semibold mb-4">Progress Trends</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Weight Progress</span>
                      <span className="text-primary font-semibold">+2.5kg</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Avg Daily Calories</span>
                      <span className="font-semibold">2,807</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Workout Consistency</span>
                      <span className="text-success font-semibold">85%</span>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 card-shadow">
                  <h3 className="text-lg font-semibold mb-4">Weekly Achievements</h3>
                  <div className="space-y-2">
                    <Badge variant="secondary">🎯 Hit protein goal 6/7 days</Badge>
                    <Badge variant="secondary">💪 Completed all workouts</Badge>
                    <Badge variant="secondary">💧 Hydration streak: 5 days</Badge>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};