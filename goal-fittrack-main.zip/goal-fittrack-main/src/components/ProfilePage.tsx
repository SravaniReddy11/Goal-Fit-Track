import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Save, User, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProfileData {
  name: string;
  age: number | null;
  sex: string;
  height_cm: number | null;
  weight_kg: number;
  target_weight_kg: number | null;
  body_fat_percentage: number | null;
  activity_level: string;
  goal: string;
  dietary_preferences: string;
  food_dislikes: string;
  meal_frequency: number | null;
  wake_time: string;
  sleep_time: string;
  water_goal_liters: number | null;
  training_days: string[];
  workout_window: string;
  injuries: string;
}

export const ProfilePage = ({ onBack }: { onBack: () => void }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<ProfileData>({
    name: "",
    age: null,
    sex: "",
    height_cm: null,
    weight_kg: 0,
    target_weight_kg: null,
    body_fat_percentage: null,
    activity_level: "",
    goal: "",
    dietary_preferences: "",
    food_dislikes: "",
    meal_frequency: null,
    wake_time: "",
    sleep_time: "",
    water_goal_liters: null,
    training_days: [],
    workout_window: "",
    injuries: "",
  });

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("No user found");

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      if (data) {
        setProfile({
          name: data.name || "",
          age: data.age,
          sex: data.sex || "",
          height_cm: data.height_cm,
          weight_kg: data.weight_kg,
          target_weight_kg: data.target_weight_kg,
          body_fat_percentage: data.body_fat_percentage,
          activity_level: data.activity_level || "",
          goal: data.goal || "",
          dietary_preferences: data.dietary_preferences || "",
          food_dislikes: data.food_dislikes || "",
          meal_frequency: data.meal_frequency,
          wake_time: data.wake_time || "",
          sleep_time: data.sleep_time || "",
          water_goal_liters: data.water_goal_liters,
          training_days: data.training_days || [],
          workout_window: data.workout_window || "",
          injuries: data.injuries || "",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error loading profile",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("No user found");

      const { error } = await supabase
        .from('profiles')
        .update({
          name: profile.name,
          age: profile.age,
          sex: profile.sex || null,
          height_cm: profile.height_cm,
          weight_kg: profile.weight_kg,
          target_weight_kg: profile.target_weight_kg,
          body_fat_percentage: profile.body_fat_percentage,
          activity_level: profile.activity_level || null,
          goal: profile.goal || null,
          dietary_preferences: profile.dietary_preferences || null,
          food_dislikes: profile.food_dislikes || null,
          meal_frequency: profile.meal_frequency,
          wake_time: profile.wake_time || null,
          sleep_time: profile.sleep_time || null,
          water_goal_liters: profile.water_goal_liters,
          training_days: profile.training_days.length > 0 ? profile.training_days : null,
          workout_window: profile.workout_window || null,
          injuries: profile.injuries || null,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Profile updated!",
        description: "Your changes have been saved successfully.",
      });
    } catch (error: any) {
      toast({
        title: "Error saving profile",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof ProfileData, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const toggleTrainingDay = (day: string) => {
    setProfile(prev => ({
      ...prev,
      training_days: prev.training_days.includes(day)
        ? prev.training_days.filter(d => d !== day)
        : [...prev.training_days, day]
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading your profile...</p>
        </div>
      </div>
    );
  }

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  return (
    <div className="min-h-screen gradient-bg">
      {/* Header */}
      <header className="bg-card/50 backdrop-blur border-b border-border/50 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Profile Settings
            </h1>
          </div>
          <Button onClick={handleSave} disabled={saving} className="gradient-primary">
            {saving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save Changes
          </Button>
        </div>
      </header>

      <div className="container mx-auto p-4 max-w-4xl space-y-6">
        {/* Basic Info */}
        <Card className="p-6 card-shadow">
          <div className="flex items-center gap-2 mb-6">
            <User className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Basic Information</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={profile.name}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="Your name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                type="number"
                value={profile.age || ""}
                onChange={(e) => updateField('age', e.target.value ? parseInt(e.target.value) : null)}
                placeholder="Your age"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sex">Sex</Label>
              <Select value={profile.sex} onValueChange={(value) => updateField('sex', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sex" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="height">Height (cm)</Label>
              <Input
                id="height"
                type="number"
                value={profile.height_cm || ""}
                onChange={(e) => updateField('height_cm', e.target.value ? parseFloat(e.target.value) : null)}
                placeholder="Height in cm"
              />
            </div>
          </div>
        </Card>

        {/* Body Metrics */}
        <Card className="p-6 card-shadow">
          <h2 className="text-xl font-semibold mb-6">Body Metrics</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weight">Current Weight (kg)</Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                value={profile.weight_kg || ""}
                onChange={(e) => updateField('weight_kg', e.target.value ? parseFloat(e.target.value) : 0)}
                placeholder="Current weight"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="target_weight">Target Weight (kg)</Label>
              <Input
                id="target_weight"
                type="number"
                step="0.1"
                value={profile.target_weight_kg || ""}
                onChange={(e) => updateField('target_weight_kg', e.target.value ? parseFloat(e.target.value) : null)}
                placeholder="Target weight"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="body_fat">Body Fat %</Label>
              <Input
                id="body_fat"
                type="number"
                step="0.1"
                value={profile.body_fat_percentage || ""}
                onChange={(e) => updateField('body_fat_percentage', e.target.value ? parseFloat(e.target.value) : null)}
                placeholder="Body fat percentage"
              />
            </div>
          </div>
        </Card>

        {/* Fitness Goals */}
        <Card className="p-6 card-shadow">
          <h2 className="text-xl font-semibold mb-6">Fitness Goals</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="goal">Primary Goal</Label>
              <Select value={profile.goal} onValueChange={(value) => updateField('goal', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="muscle_gain">Build Muscle</SelectItem>
                  <SelectItem value="fat_loss">Lose Fat</SelectItem>
                  <SelectItem value="maintenance">Maintain Weight</SelectItem>
                  <SelectItem value="recomp">Body Recomposition</SelectItem>
                  <SelectItem value="strength">Build Strength</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="activity">Activity Level</Label>
              <Select value={profile.activity_level} onValueChange={(value) => updateField('activity_level', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select activity level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedentary">Sedentary</SelectItem>
                  <SelectItem value="lightly_active">Lightly Active</SelectItem>
                  <SelectItem value="moderately_active">Moderately Active</SelectItem>
                  <SelectItem value="very_active">Very Active</SelectItem>
                  <SelectItem value="extremely_active">Extremely Active</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Schedule */}
        <Card className="p-6 card-shadow">
          <h2 className="text-xl font-semibold mb-6">Schedule & Routine</h2>
          <div className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="wake_time">Wake Time</Label>
                <Input
                  id="wake_time"
                  type="time"
                  value={profile.wake_time}
                  onChange={(e) => updateField('wake_time', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sleep_time">Sleep Time</Label>
                <Input
                  id="sleep_time"
                  type="time"
                  value={profile.sleep_time}
                  onChange={(e) => updateField('sleep_time', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="workout_window">Preferred Workout Time</Label>
                <Select value={profile.workout_window} onValueChange={(value) => updateField('workout_window', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning (6-10 AM)</SelectItem>
                    <SelectItem value="midday">Midday (10 AM-2 PM)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (2-6 PM)</SelectItem>
                    <SelectItem value="evening">Evening (6-10 PM)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Training Days</Label>
              <div className="flex flex-wrap gap-2">
                {days.map((day) => (
                  <Button
                    key={day}
                    type="button"
                    variant={profile.training_days.includes(day) ? "default" : "outline"}
                    size="sm"
                    onClick={() => toggleTrainingDay(day)}
                    className={profile.training_days.includes(day) ? "gradient-primary" : ""}
                  >
                    {day.slice(0, 3)}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Nutrition */}
        <Card className="p-6 card-shadow">
          <h2 className="text-xl font-semibold mb-6">Nutrition Preferences</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="meal_frequency">Meals Per Day</Label>
              <Select 
                value={profile.meal_frequency?.toString() || ""} 
                onValueChange={(value) => updateField('meal_frequency', parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select meals" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 meals</SelectItem>
                  <SelectItem value="4">4 meals</SelectItem>
                  <SelectItem value="5">5 meals</SelectItem>
                  <SelectItem value="6">6 meals</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="water_goal">Daily Water Goal (liters)</Label>
              <Input
                id="water_goal"
                type="number"
                step="0.5"
                value={profile.water_goal_liters || ""}
                onChange={(e) => updateField('water_goal_liters', e.target.value ? parseFloat(e.target.value) : null)}
                placeholder="Daily water goal"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dietary">Dietary Preferences</Label>
              <Textarea
                id="dietary"
                value={profile.dietary_preferences}
                onChange={(e) => updateField('dietary_preferences', e.target.value)}
                placeholder="e.g., vegetarian, keto, no gluten..."
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dislikes">Food Dislikes</Label>
              <Textarea
                id="dislikes"
                value={profile.food_dislikes}
                onChange={(e) => updateField('food_dislikes', e.target.value)}
                placeholder="Foods you want to avoid..."
                rows={2}
              />
            </div>
          </div>
        </Card>

        {/* Health Notes */}
        <Card className="p-6 card-shadow">
          <h2 className="text-xl font-semibold mb-6">Health Notes</h2>
          <div className="space-y-2">
            <Label htmlFor="injuries">Injuries or Limitations</Label>
            <Textarea
              id="injuries"
              value={profile.injuries}
              onChange={(e) => updateField('injuries', e.target.value)}
              placeholder="Any injuries or physical limitations we should know about..."
              rows={3}
            />
          </div>
        </Card>
      </div>
    </div>
  );
};
